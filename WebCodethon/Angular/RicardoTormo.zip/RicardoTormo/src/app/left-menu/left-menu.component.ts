import { Component } from '@angular/core';

@Component({
  selector: 'app-left-menu',
  standalone: true,
  imports: [],
  templateUrl: './left-menu.component.html',
  styleUrl: './left-menu.component.css'
})
export class LeftMenuComponent {

}
