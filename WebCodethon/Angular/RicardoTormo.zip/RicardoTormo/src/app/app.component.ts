import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { LeftMenuComponent } from './left-menu/left-menu.component';
import { RightSliderComponent } from './right-slider/right-slider.component';
import { ContenedorDescubreComponent } from './contenedor-descubre/contenedor-descubre.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, LeftMenuComponent, RightSliderComponent, ContenedorDescubreComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'RicardoTormo';
}
