import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

@Component({
  selector: 'app-right-slider',
  standalone: true,
  imports: [],
  templateUrl: './right-slider.component.html',
  styleUrl: './right-slider.component.css',
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class RightSliderComponent {

}
