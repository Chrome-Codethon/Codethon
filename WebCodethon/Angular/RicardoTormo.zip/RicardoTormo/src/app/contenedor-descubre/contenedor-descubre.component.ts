import { Component } from '@angular/core';

@Component({
  selector: 'app-contenedor-descubre',
  standalone: true,
  imports: [],
  templateUrl: './contenedor-descubre.component.html',
  styleUrl: './contenedor-descubre.component.css'
})
export class ContenedorDescubreComponent {

}
