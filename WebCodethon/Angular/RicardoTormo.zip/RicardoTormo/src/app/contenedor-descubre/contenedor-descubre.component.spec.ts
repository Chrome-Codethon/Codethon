import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContenedorDescubreComponent } from './contenedor-descubre.component';

describe('ContenedorDescubreComponent', () => {
  let component: ContenedorDescubreComponent;
  let fixture: ComponentFixture<ContenedorDescubreComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ContenedorDescubreComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ContenedorDescubreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
